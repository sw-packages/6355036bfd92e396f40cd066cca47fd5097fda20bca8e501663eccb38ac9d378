#ifndef NAMED_TYPE_HPP
#define NAMED_TYPE_HPP

#include "named_type_impl.hpp"
#include "underlying_functionalities.hpp"

#endif
